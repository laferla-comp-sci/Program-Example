/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs2qiz;

/**This class
 *
 * @author Trevor
 */
class PlainBox {
    String m_shape;
    String m_size;
    
    public PlainBox() {
    m_shape = "square";
    m_size = "5x5 ft";
}
    public PlainBox(String m_shape, String m_size){
        this.m_shape = m_shape;
        this.m_size = m_size;
    }
    
    public String getM_shape(){
        return m_shape;
    }
    public String getM_size(){
        return m_size;
    }
    public void setM_shape(String m_shape){
        this.m_shape = m_shape;
    }
    public void setM_size(String m_size){
        this.m_size = m_size;
    }
    @Override
     public String toString() {
    return "Box shape is " + m_shape + " and box size is " + m_size;
    }
}
