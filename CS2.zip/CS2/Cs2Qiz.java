/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs2qiz;

/**
 *
 * @author Trevor
 */
public class Cs2Qiz {
    public static void main(String[] args) {
        System.out.println("Creating a plain box object");
        PlainBox plainbox1 = new PlainBox("6 x 6", "");
        System.out.println("The shape of plain box one is " + plainbox1.getM_shape());
        System.out.println("The size of plain box one is " + plainbox1.getM_size());
        plainbox1.setM_size("smaller");
        System.out.println("The size of plain box one is " + plainbox1.getM_size());
         plainbox1.setM_shape("square");
        System.out.println("The shape of plain box one is " + plainbox1.getM_shape());
        plainbox1.toString();
        
        System.out.println("Creating a toy box object");
        ToyBox Toybox1 = new ToyBox("Ball", "White", "Bigger", "Triangular");
         System.out.println("The shape of toy box one is " + Toybox1.getM_shape());
        System.out.println("The size of toy box one is " + Toybox1.getM_size());
        Toybox1.setM_size("Smaller");
        System.out.println("The size of toy box one is " + Toybox1.getM_size());
         plainbox1.setM_shape("Square");
        System.out.println("The shape of toy box one is " + Toybox1.getM_shape());
        Toybox1.setToyBox("Bigger ball", "Brown color", "big box", "rectangular ");
        Toybox1.toString();
    }
    
}
