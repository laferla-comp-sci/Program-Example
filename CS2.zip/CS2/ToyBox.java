
package cs2qiz;

/**
 *
 * @author Trevor

* **/

class ToyBox extends PlainBox {
    
   private String m_item;
   private String m_color;
   
   
   public ToyBox(){
       m_item = "box is empty";
       m_color = "brown box";
}
   public ToyBox(String m_item, String m_color, String m_size, String m_shape){
       this.m_color = m_color;
       this.m_item = m_item;
       this.m_size = m_size;
       this.m_shape = m_shape;
    }
   public String getSize(){
       return this.m_size;
   }
   public String getShape(){
       return this.m_shape;
   }
   public void setToyBox(String m_item, String m_color, String m_size, String m_shape){
       this.m_color = m_color;
       this.m_item = m_item;
       this.m_size = m_size;
       this.m_shape = m_shape;
   }
    @Override
     public String toString() {
    return "Toy Box item inside is " + m_item + " and box size is " + m_size + "The toy box is colored " + m_color + " and the item inside is " + m_item;
    }
}
